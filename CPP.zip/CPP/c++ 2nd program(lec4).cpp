#include<iostream>
using namespace std;
int main()
{
	/*char i='A';
	while(i<='C')
	{
		int j=1;
		while(j<=3)
		{
			cout<<i;
			j++;
		}
		cout<<endl;
		i++;
	}*/
	
/*	int i=1;
	while(i<=3)
	{
		char j='A';
		while(j<='C')
		{
			cout<<j;
			j++;
		}
		cout<<endl;
		i++;
	}*/
	
	/*int i=1,j;
	char count='A';
	while(i<=3)
	{
	    j=1;
	    while(j<=3)
	    {
	    	cout<<count;
	    	count++;
	    	j++;
		}
		cout<<endl;
		i++;
	}*/
	
	/*while(i<=3)
	{
		j=1;
		char x=count;
		while(j<=3)
		{
			cout<<x;
			x++;
			j++;
		}
		cout<<endl;
		count++;
		i++;
	}*/
	
	/*while(i<=3)
	{
		j=1;
		while(j<=3)
		{
			char ch='A'+i+j-2;
			cout<<ch;
			j++;
		}
		cout<<endl;
		i++;
	}*/
	
	char ch='D';
	/*while(i<=4)
	{
		j=1;
		while(j<=i)
		{
			cout<<ch;
			j++;
		}
		cout<<endl;
		ch++;
		i++;
	}
	
	i=1;
	while(i<=3)
	{
		j=3;
		while(j>=i)
		{
			cout<<ch;
			j--;
		}
		cout<<endl;
		ch++;
		i++;
	}*/
	
	/*while(i<=4)
	{
		j=1;
		while(j<=i)
		{
			cout<<ch;
			ch++;
			j++;
		}
		cout<<endl;
		i++;
	}
	i=1;
	while(i<=3)
	{
		j=3;
		while(j>=i)
		{
			cout<<ch;
			ch++;
			j--;
		}
		cout<<endl;
		i++;
	}*/
	
	/*while(i<=4)
	{
		j=1;
		char x=ch;
		while(j<=i)
		{
			cout<<x;
			x++;
			j++;
		}
		cout<<endl;
		ch--;
		i++;
	}*/
	
	/*while(i<=4)
	{
		j=3;
		while(j>=i)
		{
			cout<<" ";
			j--;
		}
		int k=1;
		while(k<=i)
		{
			cout<<"*";
			k++;
		}
		cout<<endl;
		i++;
	}*/
	
	/*while(i<=4)
	{
		j=4;
		while(j>=i)
		{
			cout<<"*";
			j--;
		}
		cout<<endl;
		i++;
	}*/
	
	/*while(i<=4)
	{
		j=0;
		while(j<=i)
		{
			cout<<" ";
			j++;
		}
		int k=4;
		while(k>=i)
		{
			cout<<"*";
			k--;
		}
		cout<<endl;
		i++;
	}*/
	
	/*while(i<=4)
	{
		j=0;
		while(j<=i)
		{
			cout<<" ";
			j++;
		}
		int k=4;
		while(k>=i)
		{
			cout<<i;
			k--;
		}
		cout<<endl;
		i++;
	}*/
	
	/*while(i<=4)
	{
		j=3;
		while(j>=i)
		{
			cout<<" ";
			j--;
		}
		int k=1;
		while(k<=i)
		{
			cout<<i;
			k++;
		}
		cout<<endl;
		i++;
	}*/
	
	/*int x=1;
	while(i<=4)
	{
		j=0;
		while(j<=i)
		{
			cout<<" ";
			j++;
		}
		int y=x;
		int k=4;
		while(k>=i)
		{
			cout<<y;
			y++;
			k--;
		}
		cout<<endl;
		x++;
		i++;
	}*/
	
	/*int y=1;
	while(i<=4)
    {
    	j=3;
    	while(j>=i)
    	{
    		cout<<" ";
    		j--;
		}
		int k=1;
		while(k<=i)
		{
			cout<<y;
			y++;
			k++;
		}
		cout<<endl;
		i++;
	}*/
	
	/*while(i<=4)
	{
		j=3;
		while(j>=i)
		{
			cout<<" ";
			j--;
		}
		int k=1;
		while(k<=i)
		{
			cout<<k;
			k++;
		}
		int start=i-1;
		while(start)
		{
			cout<<start;
			start--;
		}
		cout<<endl;
		i++;
	}*/
	
	/*int i=1,j,n,g;
	cout<<"enter no of rows: ";
	cin>>n;
	int x=n;
	g=n;
	while(i<=n)
	{
		j=1;
		while(j<=g)
		{
			cout<<j;
			j++;
		}
		g--;
		int k=i-1;
		while(k)
		{
			cout<<"*";
			k--;
		}
		int a=i-1;
		while(a)
		{
			cout<<"*";
			a--;
		}
		int y=x;
		int b=5;
		while(b>=i)
		{
			cout<<y;
			y--;
			b--;
		}
		cout<<endl;
		x--;
		i++;
	}*/
	
	/*int i=1,j,n;
	cout<<"enter number of rows: ";
	cin>>n;
	int k=5;
	int x=k;
	
	while(i<=n)
	{
		j=5;
		int count=1;
		while(j>=i)
		{
			cout<<count;
			count++;
			j--;
		}
		int a=i-1;
		while(a)
		{
			cout<<"*";
			a--;
		}
		int b=i-1;
		while(b)
		{
			cout<<"*";
			b--;
		}
		k=5;
		int y=x;
		while(k>=i)
		{
			cout<<y;
			y--;
			k--;
		}
		cout<<endl;
		x--;
		i++;
	}
	return 0;*/
}
