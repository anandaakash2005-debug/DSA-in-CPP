#include<bits/stdc++.h>
using namespace std;
void merge(vector<int>&arr,int start,int mid,int end)
{
    vector<int>temp;
    int left=start;
    int right=mid+1;
    while(left<=mid && right<=end)
    {
        if(arr[left]<=arr[right])
        {
            temp.push_back(arr[left]);
            left++;
        }
        else
        {
            temp.push_back(arr[right]);
            right++;
        }
    }
    while(left<=mid)
    {
        temp.push_back(arr[left]);
        left++;
    }
    while(right<=end)
    {
        temp.push_back(right);
        right++;
    }
    for(int i=start;i<=end;i++)
    {
        arr[i]=temp[i-start];
    }
}
void ms(vector<int>&arr,int start,int end)
{
    if(start==end)
    return;
    int mid=(start+end)/2;
    ms(arr,start,mid);
    ms(arr,mid+1,end);
    merge(arr,start,mid,end);
}
void merge_sort(vector<int>&arr,int n)
{
    ms(arr,0,n-1);
}
int main()
{
    vector<int>arr={3,2,8,5,1,4,23};
    
    merge_sort(arr,arr.size());

    cout<<"sorted array: ";
    for(auto it:arr)
    cout<<it<<" ";

    cout<<endl;
    return 0;
}