#include<iostream>
using namespace std;

int main()
{
	/*int a=123;
	cout<<a<<endl;
	
	char b='v';
	cout<<b<<endl;
	
	bool bl= true;
	cout<<bl<<endl;
	
	float f=1.2;
	cout<<f<<endl;
	
	double d=1.23;
	cout<<d<<endl;
	
	int x='a';
	cout<<x<<endl;
	
	cout<<2.0/5<<endl;
	
	char ch=98;
	cout<<ch<<endl;
	
	int size1=sizeof(a);
	cout<<"size of a is:"<<size1<<endl;
	
	int size2=sizeof(b);
	cout<<"size of b:"<<size2<<endl;
	
	int size3=sizeof(f);
	cout<<"size of f:"<<size3<<endl;
	
	int size4=sizeof(bl);
	cout<<"size of bl is:"<<size4<<endl;
	
	int size5=sizeof(d);
	cout<<"size of d is:"<<size5<<endl;
	
	int a=3;
	int b=4;
	bool first=(a==b);
	cout<<first<<endl;
	
	bool second=(a>b);
	cout<<second<<endl;
	
	bool third=(a<b);
	cout<<third<<endl;
	
	bool fourth=(a>=b);
	cout<<fourth<<endl;
	
	bool fifth=(a<=b);
	cout<<fifth<<endl;
	
	bool sixth=(a!=b);
	cout<<sixth<<endl;*/
	
	int p=23;
	cout<<!p<<endl;
	
	int o=0;
	cout<<!o<<endl;
}
