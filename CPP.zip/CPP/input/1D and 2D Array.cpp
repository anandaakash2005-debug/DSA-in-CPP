#include<bits/stdc++.h>
using namespace std;
int main()
{
	/*int arr[3][5];
	arr[2][3]=37;
	cout<<arr[2][3]<<endl;*/
	
	string s="Akash";
	int len=s.size();
	//cout<<s[len-1]<<len;
	s[len-1]='z';
	cout<<s<<endl;
	return 0;
}
