#include<bits/stdc++.h>
using namespace std;
int main()
{
	string s="Akash";
	int len=s.size();
	cout<<len<<endl;
	s[len-1]='z';
	cout<<s<<endl;
	return 0;
}
