#include<bits/stdc++.h>
using namespace std;
//implimantation hiding
int main()
{
   return 0;
}
