console.log("from script file");
