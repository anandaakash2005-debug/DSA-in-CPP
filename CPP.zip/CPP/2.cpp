#include<bits/stdc++.h>
using namespace std;

void explainpair()
{
    // Simple pair
    pair<int,int> p1 = {1,3};
    cout << p1.first << " " << p1.second << endl;

    // Nested pair (int, pair<int, int>)
    pair<int, pair<int,int>> p2 = {5,{8,6}};
    cout << p2.first << " " << p2.second.first << " " << p2.second.second << endl;

    // Array of pairs
    pair<int,int> arr[] = {{1,2},{2,5},{5,1}};
    cout << arr[1].second << endl;
}

int main()
{
    explainpair();
    return 0;
}

