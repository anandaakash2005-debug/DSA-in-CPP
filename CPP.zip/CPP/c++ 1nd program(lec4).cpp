#include<iostream>
using namespace std;
int main()
{
int i=1,j,count=1;
/*cout<<"enter element of(nxn) matrix: ";
cin>>n;

while(i<=n)
{
	int j=1;
	while(j<=n)
	{
		cout<<j;
		j++;
	}
	cout<<endl;
	i++;
}
   while(i<=3)
   {
   	  while(j<=3)
   	  {
   	  	cout<<j<<" ";
   	  	j++;
	 }
	 cout<<endl;
	 i++;
	 while(j<=6)
   	  {
   	  	cout<<j<<" ";
   	  	j++;
	 }
	 cout<<endl;
	 
	 while(j<=9)
   	  {
   	  	cout<<j<<" ";
   	  	j++;
	 }
	 cout<<endl;
	 //or
   }
   
	while(i<=3)
	{
		j=1;
		while(j<=3)
		{
			cout<<count;
			count++;
			j++;
		}
		cout<<endl;
		i++;
	}*/
	
	/*while(i<=4)
	{
		j=1;
		while(j<=i)
		{
			cout<<"*";
			j++;
		}
		cout<<endl;
		i++;
	}
	i=1;
	while(i<=3)
	{
		j=3;
		while(j>=i)
		{
			cout<<"*";
			j--;
		}
		cout<<endl;
		i++;
	}*/
	
  /*while(i<=4)
   {
   	  j=1;
   	  while(j<=i)
   	  {
   	  	cout<<i;
   	  	j++;
	  }
	  cout<<endl;
	  i++;
   }
   
   i=1;
   while(i<=3)
   {
   	 j=3;
   	 while(j>=i)
   	 {
   	 	cout<<count;
   	 	j--;
	 }
	 cout<<endl;
	 i++;
	 count++;
   }*/
   
   /*while(i<=4)
   {
   	  j=1;
   	  while(j<=i)
   	  {
   	  	cout<<count;
   	  	count++;
   	  	j++;
	  }
	  cout<<endl;
	  i++;
   }
   
   i=1;
   while(i<=3)
   {
   	j=3;
   	while(j>=i)
   	{
   		cout<<count;
   		count++;
   		j--;
	}
	cout<<endl;
	i++;
   }*/

   while(i<=4)
   {
   	j=1;
   	int x=count;
   	while(j<=i)
   	{
   		cout<<x;
   		x--;
   		j++;
	}
	count++;
	cout<<endl;
	i++;
   }
   
   i=1;
   while(i<=3)
   {
   	j=3;
   	int y=count;
	while(j>=i)
	{
		cout<<y;
		y--;
		j--;
	 }
	 cout<<endl;
	 count++;
	 i++; 
   }
   
   
}
